% This is an -*- erlang -*- file.
%% %CopyrightBegin%
%%
%% Copyright Ericsson AB 2009-2017. All Rights Reserved.
%%
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
%%
%% %CopyrightEnd%

{application, common_test,
 [{description, "The OTP Common Test application"},
  {vsn, "1.14"},
  {modules, [ct_cover,
	     ct,
             ct_default_gl,
	     ct_event,
	     ct_framework,
	     ct_ftp,
	     ct_gen_conn,
	     ct_groups,
             ct_hooks,
             ct_hooks_lock,
	     ct_logs,
	     ct_make,
	     ct_master,
	     ct_master_event,
	     ct_master_logs,
	     ct_master_status,
	     ct_netconfc,
	     ct_conn_log_h,
	     ct_property_test,
	     ct_release_test,
	     ct_repeat,
	     ct_rpc,
	     ct_run,
	     ct_snmp,
	     ct_ssh,
	     ct_telnet_client,
	     ct_telnet,
	     ct_testspec,
	     ct_util,
	     ct_webtool,
	     ct_webtool_sup,
	     unix_telnet,
	     vts,
	     ct_config,
	     ct_config_plain,
	     ct_config_xml,
	     ct_slave,
             cth_log_redirect,
	     cth_conn_log,
             cth_surefire,
	     erl2html2,
	     test_server_ctrl,
	     test_server,
	     test_server_gl,
	     test_server_io,
	     test_server_node,
	     test_server_sup
	    ]},
  {registered, [ct_logs,
		ct_util_server,
		ct_config_server,
		ct_make_ref,
		vts,
		ct_master,
		ct_master_logs,
		test_server_ctrl,
		test_server,
		test_server_break_process]},
  {applications, [kernel,stdlib]},
  {env, []},
  {runtime_dependencies,
   ["compiler-6.0",
    "crypto-3.6",
    "debugger-4.1",
    "erts-7.0",
    "inets-6.0",
    "kernel-4.0",
    "observer-2.1",
    "runtime_tools-1.8.16",
    "sasl-2.4.2",
    "snmp-5.1.2",
    "ssh-4.0",
    "stdlib-2.5",
    "syntax_tools-1.7",
    "tools-2.8",
    "xmerl-1.3.8"
   ]}]}.

